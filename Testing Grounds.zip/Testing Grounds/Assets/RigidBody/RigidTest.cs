﻿using UnityEngine;
using System.Collections;

public class RigidTest : MonoBehaviour
{
    public KeyCode up;
    public KeyCode down;
    public KeyCode left;
    public KeyCode right;
    public KeyCode kick;
    public KeyCode Headbud;

    private KeyCode realKick;
    private KeyCode realHeadbud;

    public float MovementSpeed;
    public float RotationSpeed;
    public float KickForce;
    public float HeadbudForce;

    private Rigidbody myRigidbody;

    public GameObject Blue;
    public GameObject Red;
    private Vector3 PBlueforward;
    private Vector3 PRedforward;

    private Rigidbody RigidBlue;
    private Rigidbody RigidRed;

    private bool Kickpressed = false;
    private bool Headbudpressed = false;


    void OnTriggerStay(Collider Enter)
    {
        //Kick Code
        if(Enter.gameObject.tag == "Back")
        {
            if (gameObject == Blue)
            {
                if (Input.GetKey(realKick) && Kickpressed == false)
                {
                    Debug.Log("Red Kicks Player Blue");
                    RigidBlue.AddForce(PRedforward * KickForce * 50);
                    Kickpressed = true;
                }

            }

            if (gameObject == Red)
            {
                if (Input.GetKey(realKick) && Kickpressed == false)
                {
                    Debug.Log("Blue Kicks Player Red");
                    RigidRed.AddForce(PBlueforward * HeadbudForce * 50);
                    Kickpressed = true;
                }
            }
        }

        //Headbud Code
        if (Enter.gameObject.tag == "Front")
        {
            if (gameObject == Blue)
            {
                if (Input.GetKey(realHeadbud) && Headbudpressed == false)
                {
                    Debug.Log("Red Headbuds Player Blue");
                    RigidBlue.AddForce(-PRedforward * HeadbudForce * 50);
                    Headbudpressed = true;

                }

            }

            if (gameObject == Red)
            {
                if (Input.GetKey(realHeadbud) && Headbudpressed == false)
                {
                    Debug.Log("Blue Headbuds Player Red");
                    RigidRed.AddForce(-PBlueforward * HeadbudForce * 50);
                    Headbudpressed = true;
                }
            }
        }

    }


    // Use this for initialization
    void Start ()
    {
        //important debug code for commands, do not remove
        if (gameObject.tag == "Player1")
        {
            realKick = GameObject.FindGameObjectWithTag("Player2").GetComponent<RigidTest>().kick;
            realHeadbud = GameObject.FindGameObjectWithTag("Player2").GetComponent<RigidTest>().Headbud;
        }

        else if (gameObject.tag == "Player2")
        {
            realKick = GameObject.FindGameObjectWithTag("Player1").GetComponent<RigidTest>().kick;
            realHeadbud = GameObject.FindGameObjectWithTag("Player1").GetComponent<RigidTest>().Headbud;
        }

        //shortcut set to reach the current rigidbody
        myRigidbody = gameObject.transform.GetComponent<Rigidbody>();
        // to speed up the processing of the oncollisionstay code
        RigidRed = Red.GetComponent<Rigidbody>();
        RigidBlue = Blue.GetComponent<Rigidbody>();

    }

    // Update is called once per frame
    void Update ()
    {
        if (Input.GetKey(up))
        {
            myRigidbody.AddRelativeForce(0,0, -MovementSpeed * Time.deltaTime *50);
        }
        if (Input.GetKey(down))
        {
            myRigidbody.AddRelativeForce(0, 0, MovementSpeed * Time.deltaTime * 50);
        }
        if (Input.GetKey(left))
        {
            gameObject.transform.Rotate(new Vector3(0, RotationSpeed*Time.deltaTime *50,0));
        }
        if (Input.GetKey(right))
        {
            gameObject.transform.Rotate(new Vector3(0, -RotationSpeed * Time.deltaTime * 50, 0));
        }

        PBlueforward = Blue.transform.forward;
        PRedforward = Red.transform.forward;

        if (Input.GetKeyUp(realKick))
        {
            Kickpressed = false;
        }

        if (Input.GetKeyUp(realHeadbud))
        {
            Headbudpressed = false;
        }
    }
}
