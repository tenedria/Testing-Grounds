﻿using UnityEngine;
using System.Collections;

public class CannonBall : MonoBehaviour
{

    public Vector3 direction;
    public float ballSpeed;
    private Vector3 MovementVector;
    public float killtime;

	// Deletes the ball
	void killBall ()
    {
        Destroy(gameObject);
	}

    void Start()
    {
        //Checks when to delete the ball
        InvokeRepeating("killBall",killtime,0);
    }

	// Update is called once per frame
	void Update ()
    {
        //calculates movements
        MovementVector = ballSpeed * direction * Time.deltaTime * 500;
        //moves the ball
        gameObject.GetComponent<Rigidbody>().AddRelativeForce(MovementVector.x, MovementVector.y, MovementVector.z);
	}


}
