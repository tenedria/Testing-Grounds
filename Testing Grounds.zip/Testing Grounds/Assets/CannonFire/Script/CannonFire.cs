﻿using UnityEngine;
using System.Collections;

public class CannonFire : MonoBehaviour {

    public GameObject CannonBall;
    public Vector3 CannonBallSpawn;
    private GameObject Cannon;
    private Animation CannonAnimation;
    public AnimationClip FireCannon;
    public GameObject FireParticles;
    public GameObject FireShot;
    public GameObject[] aftersmoke;

    // Use this for initialization
    void Start ()
    {
        //finds the cannon object
        Cannon = gameObject.transform.FindChild("Cannon").gameObject;
        CannonAnimation = Cannon.GetComponent<Animation>();
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (Input.GetMouseButtonDown(0))

        {
            if (FireShot.transform.GetComponent<ParticleSystem>().duration > 0.15)
            {
                FireShot.SetActive(false);
                FireShot.SetActive(true);
                CannonAnimation.clip = FireCannon;
                CannonAnimation.Play();

                GameObject Ball = Instantiate(CannonBall, CannonBallSpawn, gameObject.transform.rotation) as GameObject;
                Ball.transform.Rotate(-8.484f, 0,0);

                if (aftersmoke[0].transform.GetComponent<ParticleSystem>().isStopped)
                {
                    aftersmoke[0].SetActive(false);
                    aftersmoke[1].SetActive(false);
                    aftersmoke[0].SetActive(true);
                    aftersmoke[1].SetActive(true);
                }
            }
            
        }
	}
}
